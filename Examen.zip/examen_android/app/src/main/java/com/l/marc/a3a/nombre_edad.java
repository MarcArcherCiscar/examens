package com.l.marc.a3a;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class nombre_edad extends AppCompatActivity {

    EditText nombre;
    EditText edad;
    Button bt;
    TextView resultado;
    MyDBAdapter dbAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nombre_edad);

        nombre=(EditText)findViewById(R.id.Nombre);
        edad=(EditText)findViewById(R.id.edad);
        bt=(Button)findViewById(R.id.enviar);
        resultado=(TextView)findViewById(R.id.resultado);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bt(nombre.getText().toString(),edad.getText().toString());
            }

        });
    }


    private void bt(String s, String e) {
        dbAdapter = new MyDBAdapter(this);
        dbAdapter.open();
        ArrayList<String> alumnos = dbAdapter.recuperarNombreyEdad(s, e);
        this.resultado.setText("");
        for(int cont=0;cont<alumnos.size();cont++){
            resultado.setText(resultado.getText()+" "+alumnos.get(cont)+"\n");

        }
    }

}
