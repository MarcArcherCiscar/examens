package com.l.marc.a3a;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class todos_profesores extends AppCompatActivity {
    TextView profs;
    private MyDBAdapter dbAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todos_profesores);
        profs=(TextView)findViewById(R.id.profs);

        dbAdapter = new MyDBAdapter(this);
        dbAdapter.open();

        ArrayList<String> alumnos = dbAdapter.recuperarProfesores();
        profs.setText("");
        for(int cont=0;cont<alumnos.size();cont++){
            profs.setText(profs.getText()+" "+alumnos.get(cont)+"\n");
        }
    }

/*
    public ArrayList<String> recuperarAlumnos(){
        ArrayList<String> alumnos = new ArrayList<String>();
        //Recuperamos en un cursor la consulta realizada
        Cursor cursor = db.query(DATABASE_TABLE_ALUMNO,null,null,null,null,null,"ciclo");
        //Recorremos el cursor
        if (cursor != null && cursor.moveToFirst()){
            do{
                String temp=cursor.getString(3);
                if(temp.trim().equals("DAM") || temp.trim().equals("DAW")) {
                    alumnos.add(cursor.getString(1)+" "+cursor.getString(2)+" "+cursor.getString(3)+" "+cursor.getString(4)+" "+cursor.getString(5));
                }
            }while (cursor.moveToNext());
        }
        return alumnos;
    }

*/


}
